import Top from './pages/Top';
import LINE from './pages/LINE';

const routes = [
  { path: '/', component: Top, exact : true },
  { path: '/line', component: LINE },
];

export default routes;