import React from 'react';
import { Link } from "react-router-dom";
import logo from '../logo.svg';
import '../App.css';

function Top() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          FitnessEngineer Reactハンズオン【PWA開発編】
        </p>
        <a
          className="App-link"
          href="https://yu-sei-m.github.io/react-pwa/#0"
          target="_blank"
          rel="noopener noreferrer"
        >
          ハンズオン資料を見る
        </a>
        <Link to="/line">SPA画面遷移ボタン</Link>
      </header>
    </div>
  );
}

export default Top;
