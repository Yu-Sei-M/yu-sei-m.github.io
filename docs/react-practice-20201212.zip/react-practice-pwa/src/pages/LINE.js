import React from 'react';
import { Link } from "react-router-dom";
import '../App.css';

const LINE = () => {
  return (
    <div className="App">
      <header className="App-header">
        <p>
          FitnessEngineer公式LINE追加ページ
        </p>
        <a
          className="App-link"
          href="https://lin.ee/tp6VjQa"
          target="_blank"
          rel="noopener noreferrer"
        >
          LINE登録して有料イベントに無料（or割引）で参加する
        </a>
        <Link to="/">Topに戻る</Link>
      </header>
    </div>
  );
}

export default LINE;
