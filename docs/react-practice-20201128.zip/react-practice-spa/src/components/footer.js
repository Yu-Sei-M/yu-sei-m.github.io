const Footer = () => <footer className="App-footer">©️2020 NPO法人FitnessEngineer</footer>

export default Footer;